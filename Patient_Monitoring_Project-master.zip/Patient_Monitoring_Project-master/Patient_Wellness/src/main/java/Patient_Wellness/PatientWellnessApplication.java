package Patient_Wellness;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PatientWellnessApplication {

	public static void main(String[] args) {
		SpringApplication.run(PatientWellnessApplication.class, args);
	}

}
